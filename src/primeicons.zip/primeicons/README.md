[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![npm version](https://badge.fury.io/js/primeicons.svg)](https://badge.fury.io/js/primeicons)

---

![PrimeIcons Logo](https://www.primefaces.org/wp-content/uploads/2018/07/primeicons-logo.svg "PrimeIcons")

Font Icon Library for Prime UI Libraries: [PrimeNG](https://www.primefaces.org/primeng/#/icons/) | [PrimeReact](https://www.primefaces.org/primereact/#/icons/) | [PrimeFaces](https://primefaces.org/showcase/icons.xhtml) | [PrimeVue](https://primefaces.org/primevue/#/icons) 

---

![Icons Preview](https://www.primefaces.org/wp-content/uploads/2020/05/primeicons-40-1.png "PrimeIcons")
